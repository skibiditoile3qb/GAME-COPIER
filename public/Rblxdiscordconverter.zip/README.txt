📁 GAME COPIER PACKAGE
This package contains an optimized streamable data bundle for your
Discord server or Roblox game, depending on selected context.

Transform the .txt file to apply it correctly.

Copyright skib co.
GNU LICENSE